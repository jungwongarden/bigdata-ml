#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

# 1行ずつ読み込み
with open('some_setting.txt') as f:
    for line in f:
        #(処理)

# または一度に読み込み
data = ''
with open('some_setting.txt') as f:
    data = f.read()

# ファイルを読み込んだ結果をmap処理/reduce処理に何らかの形で反映
for line in sys.stdin:
    #(map処理 or reduce処理)
