#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import sys
import pyper

# 基準となる情報
base_attr = [5.1, 4.9, 5.1]

# 基準となる情報とユーザ毎の情報を比較する
def cor(base_attr, user_attr):
    r = pyper.R()
    r.assign('rdata1', base_attr)
    r.assign('rdata2', user_attr)
    r('res <- cor.test(rdata1, rdata2)')
    res = r.get('res')
    cor_field = 'estimate'
    if not cor_field in res:
        return None
    return res[cor_field]

def wc_map(line):
    data = re.split(r',', line.strip())
    if (len(data) != 4):
        return None
    user_name = data[0]
    user_attr = [float(n) for n in data[1:]]
    cor_value = cor(base_attr, user_attr)
    return (cor_value, user_name)

def output(record):
    if not record:
        return
    key, value = record
    print '{0}\t{1}'.format(key, value)

for l in sys.stdin:
    output(wc_map(l))
