import java.util.List;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

public class SentenceInputFormat
    extends InputFormat<LongWritable, Text> {

  public List<InputSplit> getSplits(JobContext context
                                    ) throws IOException, 
                                             InterruptedException {
    List<InputSplit> splits = new ArrayList<InputSplit>();
    int nummaps = ((JobConf)context.getConfiguration()).getNumMapTasks();
    for (int i = 0; i < nummaps; ++i) {
      splits.add(new EmptySplit());
    }
    return splits;
  }

  public RecordReader<LongWritable, Text>
    createRecordReader(InputSplit split, TaskAttemptContext context
                       ) throws IOException, InterruptedException {
    SentenceRecordReader rr = new SentenceRecordReader();
    rr.initialize(split, context);
    return rr;
  }

  public static class EmptySplit extends InputSplit implements Writable {
    public void write(DataOutput out) throws IOException { }
    public void readFields(DataInput in) throws IOException { }
    public long getLength() { return 0L; }
    public String[] getLocations() { return new String[0]; }
  }

  public static class SentenceRecordReader
      extends RecordReader<LongWritable, Text> {
    Configuration conf = null;
    int records = 0;
    int processed = 0;
    Text sentence = null;

    public void initialize(InputSplit split, TaskAttemptContext context
                           ) throws IOException, InterruptedException {
      conf = context.getConfiguration();
      records = conf.getInt("input.sentence.records", 1);
      sentence = new Text(conf.get("input.sentence.text", "default sentence"));
    }

    public boolean nextKeyValue() throws IOException, InterruptedException {
      return  records > processed++;
    }

    public LongWritable getCurrentKey() { return new LongWritable(0L); }
    public Text getCurrentValue() { return sentence; }
    public float getProgress() { return (float)processed / records; }
    public synchronized void close() throws IOException {}
  }
}
