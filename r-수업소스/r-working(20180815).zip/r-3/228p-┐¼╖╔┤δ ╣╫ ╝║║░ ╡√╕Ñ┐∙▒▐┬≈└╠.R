gender_income <- welfare %>% 
              filter(!is.na(income)) %>% 
              group_by(ageg, gender) %>% 
              summarise(mean_income = mean(income))

gender_income

ggplot(data = gender_income, aes(x = ageg, y = mean_income, fill = gender)) +
  geom_col() +
  scale_x_discrete(limits = c("young", "middle", "old"))

ggplot(data = gender_income, aes(x = ageg, y = mean_income, fill = gender)) +
  geom_col(position = "dodge") +
  scale_x_discrete(limits = c("young", "middle", "old"))

gender_age <- welfare %>% 
  filter(!is.na(income)) %>% 
  group_by(age, gender) %>% 
  summarise(mean_income = mean(income))

head(gender_age)

ggplot(data = gender_age, aes(x = age, y = mean_income, col=gender)) + geom_line()


