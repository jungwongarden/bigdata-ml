
class(welfare$income)

summary(welfare$income)
# > summary(welfare$income)
#    Min. 1st Qu.  Median    Mean 3rd Qu.    Max.    NA's 
#     0.0   122.0   192.5   241.6   316.6  2400.0   12030
#=> NA's 이상치 

qplot(welfare$income)

qplot(welfare$income) + xlim(0, 1000) #x축 값 0~1000
welfare$income <- ifelse(welfare$income %in% c(0, 9999), NA, welfare$income)

table(is.na(welfare$income))

gender_income <- welfare %>% 
                filter(!is.na(income)) %>% 
                group_by(gender) %>% 
                summarise(mean_income = mean(income))

gender_income

ggplot(data = gender_income, aes(x = gender, y = mean_income)) + geom_col()
