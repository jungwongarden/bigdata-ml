install.packages("foreign")
library(foreign)
library(dplyr)
library(ggplot2)
install.packages("readxl")
library(readxl)

raw_welfare <- read.spss(file="Koweps_hpc10_2015_beta1.sav",
                         to.data.frame = T)

welfare <- raw_welfare

# head(welfare)
# tail(welfare)
# View(welfare)
# dim(welfare)
# str(welfare)
# summary(welfare)

welfare <- rename(welfare, 
                  gender = h10_g3,
                  birth = h10_g4,
                  marriage = h10_g10,
                  religion = h10_g11,
                  income = p1002_8aq1,
                  code_job=h10_eco9,
                  code_region=h10_reg7
                  )

# > count(welfare, gender)
# # A tibble: 2 x 2
#   gender     n
#    <dbl> <int>
# 1      1  7578
# 2      2  9086

# table(welfare) =>데이타의 양이 많아 너무 오래 걸림. 
# table(welfare$gender)
# 
class(welfare$gender)
str(welfare$gender)
# > class(welfare$gender)
# [1] "numeric"
# > str(welfare$gender)
#  num [1:16664] 2 2 1 1 2 1 2 2 1 2 ...
#  
welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)

table(is.na(welfare$gender))

# > welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)
# > table(is.na(welfare$gender))
# FALSE 
# 16664 
# 

welfare$gender <- ifelse(welfare$gender == 1, '남', '여')
table(welfare$gender)
# > welfare$gender <- ifelse(welfare$gender == 1, '남', '여')
# > table(welfare$gender)
# 
#   남   여 
# 7578 9086 

qplot(welfare$gender)



# 성별 변수 전처리 작업 완료
# 




