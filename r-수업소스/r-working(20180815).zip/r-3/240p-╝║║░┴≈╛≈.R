job_male <- welfare %>% 
  filter(!is.na(job) & gender == "남") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>%  #n()= count()개념 
  arrange(desc(n)) %>% 
  head(10)

job_male


job_income
job <- job_income$job
job



job_female <- welfare %>% 
  filter(!is.na(job) & gender == "여") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>%  #n()= count()개념 
  arrange(desc(n)) %>% 
  head(10)


# rm(job_femal)

ggplot(data = job_male, aes(x = reorder(job, n), y = n)) +
  geom_col() + #geom_col은 요약표를 이용해 그래프를 그릴 때 
  coord_flip()

ggplot(data = job_female, aes(x = reorder(job, n), y = n)) +
  geom_col() +
  coord_flip()


