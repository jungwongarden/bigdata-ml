exam %>% arrange(math)
exam %>% arrange(desc(math))
exam %>% arrange(math, class)

mpg %>% filter(company == "audi") %>% 
        select(hwy) %>%  
        arrange(desc(hwy)) %>%  
        head


                 