m(dplyr)
data <- read.csv("csv_exam.csv") #파일명도 자동 완성됨.
data$math #변수 출력 => 옆으로 프린트 (한글은 다 치고, 스페이스바를 한번 더 해주고 마무리 해주어야 글자가 잘리지 않음)

data %>% select(english) #select는 추출함수트 => 아래로 프린트 
data %>% select(english, math, class)
data %>% select(-english, -class)

#가독성 있게 줄바꾸기  

data  %>% filter(class == 1) %>% select(english, class) # %>% 는 함수로 연결시킬 때 사용 
# data  %>% filter(class == 1) %>% data$english => 함수 연결이 아니므로 사용 불가 

data$english #컨트롤+D는 삭제  

data %>%  select(id, math) %>%  head




