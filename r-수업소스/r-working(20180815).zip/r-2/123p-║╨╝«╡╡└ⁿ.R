midwestData <- as.data.frame(ggplot2::midwest)
midwestData <- rename(midwestData, total = poptotal)
midwestData <- rename(midwestData, asian = popasian)
midwestData$asianPercent <- (midwestData$asian/midwestData$total)*100
hist(midwestData$asianPercent)
midwestData$asianPercent
midwestData$asian
midwestData$total
str(midwestData)
mean(midwestData$asian)
meanAsian <- mean(midwestData$asian)
midwestData$asianResult <- ifelse(midwestData$asian > meanAsian, "large", "small")
qplot(midwestData$asianResult)
table(midwestData$asianResult)
