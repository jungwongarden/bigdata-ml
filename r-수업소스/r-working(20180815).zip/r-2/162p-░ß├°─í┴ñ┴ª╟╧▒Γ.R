df <- data.frame(gender = c("M", "F", NA, "M", "F"),
                 score = c(5,4,3,2,NA))

df

is.na(df)

table(is.na(df))

table(is.na(df$gender))

table(is.na(df$score))

# > table(is.na(df))
# 
# FALSE  TRUE 
# 8     2 
# > table(is.na(df$gender))
# 
# FALSE  TRUE 
# 4     1 
# > table(is.na(df$score))
# 
# FALSE  TRUE 
# 4     1 
# 
# 

# > mean(df$score)
# [1] NA
# > mean(df$gender)
# [1] NA
# Warning message:
#   In mean.default(df$gender) :
#   인자가 수치형 또는 논리형이 아니므로 NA를 반환합니다
#   

df %>% filter(is.na(score))
df %>% filter(!is.na(score))

# > df %>% filter(is.na(score))
# gender score
# 1      F    NA
# > df %>% filter(!is.na(score))
# gender score
# 1      M     5
# 2      F     4
# 3   <NA>     3
# 4      M     2

df_nomiss <- df %>% filter(!is.na(score))
mean(df_nomiss$score)
sum(df_nomiss$score)

# > df_nomiss <- df %>% filter(!is.na(score))
# > mean(df_nomiss$score)
# [1] 3.5s
# > sum(df_nomiss$score)
# [1] 14
# 

df_nomiss <- df %>%  filter(!is.na(score) & !is.na(gender))
df_nomiss
# > df_nomiss <- df %>%  filter(!is.na(score) & !is.na(gender))
# > df_nomiss
# gender score
# 1      M     5
# 2      F     4
# 3      M     2


df_nomiss2 <- na.omit(df)
df_nomiss2 

mean(df$score, na.rm = T) #na.rm(NA remove):결측치 제거 
sum(df$score, na.rm = T)

exam <- read.csv("csv_exam.csv")
exam[c(3,8,15), "math"]
exam[c(3,8,15), "math"] <- NA # 3,8,15행 math열에 NA를 할당 

# > exam <- read.csv("csv_exam.csv")
# > exam[c(3,8,15), "math"]
# [1] 45 90 75
# > exam[c(3,8,15), "math"] <- NA
# > exam
# id class math english science
# 1   1     1   50      98      50
# 2   2     1   60      97      60
# 3   3     1   NA      86      78
# 4   4     1   30      98      58
# 5   5     2   25      80      65
# 6   6     2   50      89      98
# 7   7     2   80      90      45
# 8   8     2   NA      78      25
# 9   9     3   20      98      15
# 10 10     3   50      98      45
# 11 11     3   65      65      65
# 12 12     3   45      85      32
# 13 13     4   46      98      65
# 14 14     4   48      87      12
# 15 15     4   NA      56      78
# 16 16     4   58      98      65
# 17 17     5   65      68      98
# 18 18     5   80      78      90
# 19 19     5   89      68      87
# 20 20     5   78      83      58
# 


exam %>% summarise(mean_math = mean(math))
exam %>% summarise(mean_math = mean(math, na.rm = T))
exam %>% summarise(mean_math = mean(math, na.rm = T),
                   sum_math = sum(math, na.rm = T),
                   median_math = median(math, na.rm = T))

# 결측치 대체 하기 
mean(exam$math,na.rm = T)

exam$math <- ifelse(is.na(exam$math), 55, exam$math)
table(is.na(exam$math)) #table(정리해서 보여주기) 
exam$math

mean(exam$math)

# 혼자서 해보기(170p)
mpg <- as.data.frame(ggplot2::mpg)
mpg[c(65, 124, 131, 153, 121), "hwy"] <- NA #65~행의 hwy열 값을 NA로 set

is.na(mpg$drv)
table(is.na(mpg$drv))
table(is.na(mpg$hwy))

# > table(is.na(mpg$drv))
# 
# FALSE 
# 234 
# > table(is.na(mpg$hwy))
# 
# FALSE  TRUE 
# 229     5 

mpg %>% filter(!is.na(hwy)) %>%  group_by(mpg$drv) %>%  summarise(result = mean(hwy))
table(result)

outlier <- data.frame(gender = c(1,2,1,3,2,1),
                      score = c(5, 4, 3, 4, 2, 6))
outlier
# > outlier <- data.frame(gender = c(1,2,1,3,2,1),
#                         +                       score = c(5, 4, 3, 4, 2, 6))
# > outlier
# gender score
# 1      1     5
# 2      2     4
# 3      1     3
# 4      3     4
# 5      2     2
# 6      1     6
# > 

outlier$gender <- ifelse(outlier$gender == 3, NA, outlier$gender)
outlier                    

outlier$score <- ifelse(outlier$score > 5, NA, outlier$score)
outlier

outlier %>%  
  filter(!is.na(gender) & !is.na(score)) %>% 
  group_by(gender) %>% 
  summarise(mean_score = mean(score))

# > outlier %>%  
#   +   filter(!is.na(gender) & !is.na(score)) %>% 
#   +   group_by(gender) %>% 
#   +   summarise(mean_score = mean(score))
#   
# # A tibble: 2 x 2
# gender mean_score
# <dbl>      <dbl>
#   1         1          4
#   2         2          3
#   
boxplot(mpg$hwy)$stats

mpg$hwy <- ifelse(mpg$hwy<12 | mpg$hwy > 37, NA, mpg$hwy)

