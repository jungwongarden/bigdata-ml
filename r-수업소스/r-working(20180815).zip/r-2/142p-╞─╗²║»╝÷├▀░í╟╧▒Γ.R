data %>% mutate(total = math)

data
data %>% mutate(total = math + english + science)
data %>% mutate(total = math + english + science) %>% head() 
data %>% mutate(total = math + english + science, 
                mean = (math + english + science)/3) %>% head() 
data %>% mutate(test = ifelse(science >= 60, "패스", "패일")) 

data

mpgCopy <- mpg
mpgCopy %>%  mutate(합산연비연수  = hwy + cty);
mpgCopy %>%  mutate(합산연비연수  = hwy + cty) %>% 
             mutate(평균연비연수 = 합산연비연수/2)
# 세미콜론이 있는 경우 블록 잡지 않고, 그냥 실행하면 됨.



