library(dplyr)
exam <- read.csv("csv_exam.csv")
exam
#컨트롤+쉬프트+M => %>% 파이프 연산자
#
exam %>% filter(class == 1)
exam %>% filter(class == 2) #shift+alt+arrow(copy)
exam %>% filter(class != 1)
exam %>% filter(class != 3)
exam %>% filter(math>50)
exam %>% filter(math<50)
exam %>% filter(english>=80)
exam %>% filter(english<=80)
exam %>% filter(class == 1 & math >= 50)
exam %>% filter(math >= 90 | english >= 90)
exam %>% filter(english < 90 | science < 50)
exam %>%  filter(class == 1 | class == 3 | class == 5)
exam %>% filter(class %in% c(1,3,5)) #%in% 매치연산자
class1 <- exam %>% filter(class == 1)
class2 <- exam %>% filter(class == 2)
mean(class1$math)
mean(class2$math)

################################
#mpg데이타로 문제 해결하기(1)
################################

mpg
#remove(displResult)
displResult1 <- mpg %>% filter(displ <= 4)  
displResult2 <- mpg %>% filter(displ >= 5)
hwy1 <- mean(displResult1$hwy)
hwy2 <- mean(displResult2$hwy)
hwyResult <- ifelse(hwy1>hwy2, "배기량이 4이하인 자동차", "배기량이 5이상인 자동차")
hwyResult



################################
#mpg데이타로 문제 해결하기(2)
################################





