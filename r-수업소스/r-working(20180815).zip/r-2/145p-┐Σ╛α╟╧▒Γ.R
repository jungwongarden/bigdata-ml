#summerize, group-by

data %>% summarise(mean_math = mean(math))
# 평균을 구하고, 파생변수를 만들어 저장하여 출력하는 방법 3가지 
## 1. 파이프 연산자를 사용 -----------------------
#> data %>% summarise(mean_math = mean(math))
#mean_math
#1     57.45
#
## 2. ------------------------------------------
#> result <- mean(data$math)
#> result
#[1] 57.45
#
## 3. ------------------------------------------
#> mean(data$math)
#[1] 57.45
#







data %>%  
  group_by(class) %>% 
  summarise(mean_math = mean(math))


data %>% 
  group_by(class) %>% 
  summarise(mean_math = mean(math),
            sum_math = sum(math),
            median_math = median(math),
            n = n()) #학생 수 

#> mean(data$math)
#[1] 57.45
#> sd(data$english)
#[1] 12.87552
#> sum(data$class)
#[1] 60
#> max(data$science)
#[1] 98
#> min(data$id)
#[1] 1

data %>%  
    summarise(n()) #n()는 summarise내에서 사용 가능  

# mpg %>% 
#   group_by(manufacturer, drv) %>% #=> manufacturer
#   head()  

mpg %>% 
  group_by(company, drv) %>% 
  head()  

# > mpg %>% 
#   +   group_by(company, drv) %>% 
#   +   head()
# A tibble: 6 x 12
# Groups:   company, drv [1]
# company model displ  year   cyl trans      drv     cty   hwy fl    class   total
# <chr>   <chr> <dbl> <int> <int> <chr>      <chr> <int> <int> <chr> <chr>   <dbl>
#   1 audi    a4      1.8  1999     4 auto(l5)   f        18    29 p     compact  23.5
# 2 audi    a4      1.8  1999     4 manual(m5) f        21    29 p     compact  25  
# 3 audi    a4      2    2008     4 manual(m6) f        20    31 p     compact  25.5
# 4 audi    a4      2    2008     4 auto(av)   f        21    30 p     compact  25.5
# 5 audi    a4      2.8  1999     6 auto(l5)   f        16    26 p     compact  21  
# 6 audi    a4      2.8  1999     6 manual(m5) f        18    26 p     compact  22  

mpg

mpg %>% group_by(desc(company)) %>% head

library(dplyr)

mpg %>% 
    group_by(company) %>% 
    filter(class == "suv") %>% 
    mutate(tot = (cty+hwy)/2) %>% 
    summarise(mean_tot = mean(tot)) %>% 
    arrange(desc(mean_tot)) %>% 
    head(5)

# > mpg %>% 
#   +     group_by(company) %>% 
#   +     filter(class == "suv") %>% 
#   +     mutate(tot = (cty+hwy)/2) %>% 
#   +     summarise(mean_tot = mean(tot)) %>% 
#   +     arrange(desc(mean_tot)) %>% 
#   +     head(5)
# # A tibble: 5 x 2
# company mean_tot
# <chr>      <dbl>
#   1 subaru      21.9
# 2 toyota      16.3
# 3 nissan      15.9
# 4 mercury     15.6
# 5 jeep        15.6








