install.packages("rJava")
install.packages("memoise")
install.packages("KoNLP")

library(KoNLP)
library(dplyr)

useNIADic()

txt <- readLines("hiphop.txt")
head(txt)

install.packages("stringr")
library(stringr)

txt <- str_replace_all(txt, "\\W", " ")


extractNoun("대한민국의 영토는 한반도와 그 부속도로로 한다.")

nouns <- extractNoun(txt)
nouns

unlist(nouns)
table(unlist(nouns))      
wordcount <- table(unlist(nouns))
df_word <- as.data.frame(wordcount, stringsAsFactors = F)
df_word <- rename(df_word,
                  word = Var1,
                  freq = Freq)
df_word <- filter(df_word, nchar(word) >= 2)

top_20 <- df_word %>% 
  arrange(desc(freq)) %>% 
  head(200)

top_20

install.packages("wordCount")
library(wordcloud)
library(RColorBrewer)
pal <- brewer.pal(8, "Dark2")
set.seed(2000)

wordcloud(words = df_word$word,
          freq = df_word$freq,
          min.freq = 2,
          max.words = 200,
          random.color = F,
          rot.per = .1,
          scale = c(4, 0.3),
          colors = pal)
