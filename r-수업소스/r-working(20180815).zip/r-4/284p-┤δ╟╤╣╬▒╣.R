install.packages("stringi")
install.packages("devtools")
install.packages("mapproj")
library(kormaps2014)
library(dplyr)
library(ggiraphExtra)
library(mapproj)
library(ggplot2)


devtools::install_github("cardiomoon/kormaps2014")

str(changeCode(korpop1))

korpop1

korpop1 <- rename(korpop1,
                  pop = "총인구_명",
                  name = "행정구역별_읍면동") 


str(korpop1)

str(kormap1)

options(encoding = "UTF-8")
ggChoropleth(data = korpop1,
             aes(fill = pop,
                 map_id = code,
                 tooltip = name),
             map = kormap1,
             interactive = T)

#################################################
str(changeCode(tbc))
options(encoding = "UTF-8")
ggChoropleth(data = tbc,
             aes(fill = NewPts,
                 map_id = code,
                 tooltip = name),
             map = kormap1,
             interactive = T)
