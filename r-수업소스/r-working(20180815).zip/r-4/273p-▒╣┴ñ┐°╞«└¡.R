twitter <- read.csv("twitter2.csv", header = T, stringsAsFactors = F)
twitter

library(dplyr)
library(KoNLP)
library(stringr)

twitter <- rename(twitter, no=번호, id=계정이름, date=작성일, tw=내용)
twitter
twitter$tw <- str_replace_all(twitter$tw, "\\W", " ") #W는 대문자
head(twitter$tw)

nouns <- extractNoun(twitter$tw)
nouns

wordcount <- table(unlist(nouns))

df_word <- as.data.frame(wordcount, stringsAsFactors = F)
df_word

df_word <- rename(df_word, word = Var1, freq = Freq)
df_word

df_word <- filter(df_word, nchar(word) >= 2)
df_word

top20 <- df_word %>%  
  arrange(desc(freq)) %>% 
  head(20)

top20

library(ggplot2)

order <- arrange(top20, freq)$word

ggplot(data = top20, aes(x = word, y = freq)) + 
  ylim(0, 2500) + 
  geom_col() +
  coord_flip() +
  scale_x_discrete(limits = order) +
  geom_text(aes(label = freq), hjust = 0.3)

library(wordcloud)
library(RColorBrewer)

pal <- brewer.pal(8, "Dark2")

set.seed(1234)

wordcloud(words = df_word$word,
          freq = df_word$freq,
          min.freq = 10,
          max.words = 500,
          random.order = F,
          rot.per = 0.1,
          scale = c(10, 0.5),
          colors = pal)

################################################
pal <- brewer.pal(9, "Blues")[5:9]

set.seed(1234)

wordcloud(words = df_word$word,
          freq = df_word$freq,
          min.freq = 10,
          max.words = 500,
          random.order = F,
          rot.per = 0.1,
          scale = c(10, 0.5),
          colors = pal)

################################################
library(RColorBrewer)

pal <- brewer.pal(9, "Set3")[3:9]
pal <- brewer.pal(9, "Set1")[3:9]
pal <- brewer.pal(9, "RdBu")[1:9]
pal <- brewer.pal(1, "RdBu")[1:9]
pal <- brewer.pal(32, "RdBu")[1:9]

set.seed(1234)

wordcloud(words = df_word$word,
          freq = df_word$freq,
          min.freq = 10,
          max.words = 500,
          random.order = F,
          rot.per = 0.1,
          scale = c(10, 0.5),
          colors = pal)
