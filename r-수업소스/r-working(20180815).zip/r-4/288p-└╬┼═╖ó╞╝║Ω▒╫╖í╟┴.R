install.packages("plotly")
library(plotly)
library(ggplot2)

#####################################
#Plots뷰를 통해,
#그래프만 한번 그릴 것이면, 아래와 같이만 해도  됨.
ggplot(data = mpg, 
            aes(x = displ,
                y = hwy,
                col = drv)) +
              geom_point()



#####################################
#View를 통해,
#인터랙티브 하려면, 아래와 같이 해야 함. 
p <- ggplot(data = mpg, 
            aes(x = displ,
                y = hwy,
                col = drv)) +
            geom_point()

ggplotly(p)                

##Zoom -> double click -> original
##

p <- ggplot(data = diamonds, 
            aes(x = cut,
                fill = clarity )) +
            geom_bar()

ggplotly(p)  

####################################
p <- ggplot(data = diamonds, 
aes(x = cut,
    fill = clarity )) +
  geom_bar(position = "dodge")

ggplotly(p)

####################################

diamonds

