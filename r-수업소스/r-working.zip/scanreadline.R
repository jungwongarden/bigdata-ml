b <- scan() #숫자를 입력 
print(b)

c1 <- readline("이름을 입력>> ") #무조건 문자로 입력 
c2 <- readline("나이를 입력>> ")
c3 <- as.integer(c2)

f1 <- function(age){
  cat("당신의 나이는: ",  age)
}

f1(c3)

hi <- read.csv("hiphop.txt")
print(hi)
#####################################################
library("readxl")
hi2 <- read_excel("excel_exam.xlsx")
hi2

c1 <- "안녕하세요..."
write.csv(c1, "file1.txt", fileEncoding = "utf-8")
c2 <- read.csv("file1.txt", fileEncoding = "utf-8")
print(c2)


#####################################################
install.packages("lubridate")
library(lubridate)
date <- now()
print(date)
year <- year(date)

if(year == 2018){
  print("올해이군요!")
}else if(year == 2017){
  print("작년이군요!")
}else if(year == 2019){
  print("내년이군요!")
}else{
  print("조건에 맞지 않는군요")
}
#####################################################
age <- scan()
name <- scan(what="")

cat("당신의 나이는 ", age)
cat("당신의이름은 ", name)


# 
x <- scan("scan.txt", what="")
x

#
for(i in 1:10){
  print(x[i])
}


library(readxl)
library(ggplot2)

df_exam <- read_excel("excel_exam.xlsx")
df_exam
write.csv(df_exam, file="saveFile.csv")

df_exam2 <- read.csv("saveFile.csv")
df_exam2
View(df_exam)

var1 <- df_exam$math
str(var1)
table(var1)
summary(var1)

qplot(data=df_exam, math)
qplot(data=df_exam, x = id, y = math)



for(i in c(1:5)){
  print("&")
}


i = 0
while(i < 5){
  print("*")
  i = i + 1
}

i = 0
repeat{
  print("@")
  i = i + 1
  if(i == 5) break
}

i = 0
if(i < 5){
  print("5보다 작은 숫자이군요.!")
}

i = "감자"
if(i == "감자"){
  print("감자를 좋아하는 군요!!")
  cat("test", "\n")
  cat("test2")
}else if(i == "고구마"){
  print("고구마를 좋아하는 군요!!")
}else{
  print("다른 것을 좋아하는 군요!!")
}

i = 99
result = ifelse(i>90, "수", "수아님")
print(result)

cat("test")
cat("test2")

empname <- scan(what="")
empname

switch(empname, 
       hong = 250, 
       lee = 350,
       kim = 200,
       kang = 400
       )


name <- c("kim", "lee", "choi", "park")
name
which(name == "choi")

no <- c(1:5)
name <- c("홍길동", "이순신", "강감찬", "유관순", "김유신")
score <- c(85, 78, 89, 90, 74)
exam <- data.frame(학번=no, 이름=name, 성적=score)
exam
which(exam$이름 == "유관순")
exam[4,]

exam2 <- exam[-1,] #exam의 1행을 삭제
exam2

exam3 <- exam[,-2] #exam의 2열을 삭제
exam3

exam4 <- exam[-c(1:2),] #exam의 1행부터 2행을 삭제
exam4

exam5 <- exam[,-2] #exam의 2열을 삭제
exam5

exam6 <- exam[,-c(2:3)] #exam의 2열을 삭제
exam6


exam7 <- exam[,-c(1,3)] #exam의 2열을 삭제
exam7

exam$addClm <- c(1,2,3,4,5)
exam

