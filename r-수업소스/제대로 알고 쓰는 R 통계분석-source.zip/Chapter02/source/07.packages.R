install.packages("prob")
library("prob")
tosscoin(1)
detach("package:prob", unload=T)
