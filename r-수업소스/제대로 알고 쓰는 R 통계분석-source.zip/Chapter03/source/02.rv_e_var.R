x <- c(0, 1, 2)
px <- c(1/4, 2/4, 1/4)
EX <- sum( x * px )
EX
x * 2
x * (1:6)
x * (1:4)
VX <- sum(x^2 * px) - EX^2
VX