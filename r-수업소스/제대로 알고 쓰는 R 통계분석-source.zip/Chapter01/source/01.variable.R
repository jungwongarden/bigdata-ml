x <- 3	
x		
x <- 5	
x
y <- 3

temp <- y 	
temp 	
y		
y <- x	
y
x
x <- temp
x
y

x2 <- NULL