x <- 3
y <- 2
x / y

xi <- 1 + 2i
yi <- 1 - 2i
xi + yi

str <- "string"
str

TRUE
FALSE